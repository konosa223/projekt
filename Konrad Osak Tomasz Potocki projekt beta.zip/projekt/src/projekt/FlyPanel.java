package projekt;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class FlyPanel extends JPanel {
	int time = 0;
	Graphics g;
	Cow tcow;
	BufferedImage background;
	BufferedImage image;

	void newCow(Cow cow) {
		tcow = cow; 
	}
	
public FlyPanel(String Background){

	File inputFile = new File(Background);
	try {
		background = ImageIO.read(inputFile);
	} catch(IOException ex) {
		System.out.println(ex.getMessage());
	}
//	File cowFile = new File("cow.jpg");
//	try {
//		image = ImageIO.read(cowFile);
//	} catch(IOException ex) {
//		System.out.println(ex.getMessage());
//	}
	
		tcow = new Cow(-100,-100,0,0,0,0);				
	}
	
	public void paint(Graphics g) {		
		Graphics2D g2D = (Graphics2D)g;
		g2D.drawImage(background,0,0,this);								
//		g2D.setColor(Color.green);		
//		g2D.fillOval((int)tcow.getX(), this.getHeight()-50 - (int)tcow.getY(), 50, 50);
		 Image image = new ImageIcon("cow.jpg").getImage(); 
		 g2D.clip(new Ellipse2D.Double((int)tcow.getX(), this.getHeight()-50 - (int)tcow.getY(), 50, 50));
		 g2D.drawImage(image,(int)tcow.getX(), this.getHeight()-50 - (int)tcow.getY(), null);
	}
	void addtime() {
		tcow.timeflow();
		repaint();
	}
	
	void setBackground(String Background) {
		File inputFile = new File(Background);
		try {
			background = ImageIO.read(inputFile);
		} catch(IOException ex) {
			System.out.println(ex.getMessage());
		}
		
	}
	
}

