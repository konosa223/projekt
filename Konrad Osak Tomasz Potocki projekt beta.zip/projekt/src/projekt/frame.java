package projekt;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class frame extends JFrame {
	
	FlyPanel flypanel = new FlyPanel("saturn.jpg");
	BottomPanel bottomPanel=new BottomPanel();
	OpeningPanel opening=new OpeningPanel();
	MenuBar menu=new MenuBar();
	double g=9; //wstawić wartość bazową
	double wi=-400; //wstawić wartość bazową
	
	public frame(){
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setSize(1280,640);
		this.menu.Moon.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("ksiezyc.jpg");
				setWi(0);
				setG(1.622);
			}
		});
		this.menu.Neptune.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("neptun.jpg");
				setWi(600);
				setG(11);
			}
		});
		this.menu.Mars.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("mars.jpg");
				setWi(-300);
				setG(3.7);
			}
		});
		this.menu.Pluto.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("pluto.jpg");
				setWi(10);
				setG(0.62);
			}
		});
		this.menu.Saturn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("saturn.jpg");
				setWi(-400);
				setG(9);
			}
		});
		this.opening.moon.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("ksiezyc.jpg");
				setWi(0);
				setG(1.622);
				opening.setVisible(false);
				add(flypanel,BorderLayout.CENTER);
			}
		});
		this.opening.neptun.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("neptun.jpg");
				setWi(600);
				setG(11);
				opening.setVisible(false);
				add(flypanel,BorderLayout.CENTER);
			}
		});
		this.opening.mars.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("mars.jpg");
				setWi(-300);
				setG(3.7);
				opening.setVisible(false);
				add(flypanel,BorderLayout.CENTER);
			}
		});
		this.opening.pluto.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("pluto.jpg");
				setWi(10);
				setG(0.62);
				opening.setVisible(false);
				add(flypanel,BorderLayout.CENTER);
			}
		});
		this.opening.saturn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				flypanel.setBackground("saturn.jpg");
				setWi(-400);
				setG(9);
				opening.setVisible(false);
				add(flypanel,BorderLayout.CENTER);
			}
		});
		this.setJMenuBar(menu.getMenuBar());
		this.add(opening,BorderLayout.CENTER);
		//this.add(flypanel,BorderLayout.CENTER);
		this.add(bottomPanel,BorderLayout.SOUTH);
		this.setVisible(true);
	}
	
	void addtime() {
		flypanel.addtime();
		
	}
	void newCow(Cow cow) {
		flypanel.newCow(cow);
	}
	void trybackground() {
		flypanel.setBackground("mars.jpg");
	}

	public double getG() {
		return g;
	}

	public void setG(double g) {
		this.g = g;
	}

	public double getWi() {
		return wi;
	}

	public void setWi(double wi) {
		this.wi = wi;
	}

}
