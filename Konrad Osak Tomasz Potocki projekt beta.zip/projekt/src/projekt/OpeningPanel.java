package projekt;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.LayoutManager;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OpeningPanel extends JPanel {
	JButton moon=new JButton("Księżyc");
	JButton saturn=new JButton("Saturn");
	JButton neptun=new JButton("Neptun");
	JButton mars=new JButton("Mars");
	JButton pluto=new JButton("Pluton");
	JLabel lab=new JLabel("Wybierz planetę");
	public OpeningPanel() {
		setBackground(Color.cyan);
		lab.setHorizontalAlignment(JLabel.CENTER);
		add(lab);
		add(Box.createRigidArea(new Dimension(70, 0)));

		setLayout(new GridBagLayout());
		add(mars);
		add(Box.createRigidArea(new Dimension(70, 0)));
		add(moon);
		add(Box.createRigidArea(new Dimension(70, 0)));
		add(neptun);
		add(Box.createRigidArea(new Dimension(70, 0)));
		add(pluto);
		add(Box.createRigidArea(new Dimension(70, 0)));
		add(saturn);
	}

}
