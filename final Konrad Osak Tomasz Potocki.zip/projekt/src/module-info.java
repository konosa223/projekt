/**
 * 
 */
/**
 * 
 */
module projekt {
	requires java.desktop;
}